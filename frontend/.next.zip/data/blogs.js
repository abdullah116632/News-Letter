export const blogs = [
    {
      _id: 1,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP 5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP INGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP 5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes .................................................. Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 2,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 3,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 4,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 5,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 6,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 7,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 8,
      img: "/images/blogimage.png",
      title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
      description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
    },
    {
      _id: 9,
        img: "/images/blogimage.png",
        title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
        description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
      },
      {
        _id: 10,
        img: "/images/blogimage.png",
        title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
        description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
      },
      {
        _id: 11,
        img: "/images/blogimage.png",
        title: "5 THINGS YOU NEED TO KNOW BEFORE APPLYING FOR ANY SCHOLARSHIP",
        description: "Before you dive into the scholarship application process, it’s important to be well-prepared. Here are 5 crucial things you need to know before applying for any scholarship: 1. Understand the Eligibility Criteria Carefully read the requirements like academic qualifications, nationality, field of study, age limits, and financial need. Applying without meeting the basic criteria wastes your time.2. Prepare Strong Documents You'll typically need an updated CV, transcripts, recommendation letters, personal statement, and sometimes ..................................................",
      },
  ];