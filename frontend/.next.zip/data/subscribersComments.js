export const comments = [
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying., This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying., This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying., This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
    {
      name: "arnab samaddar",
      profession: "Student | Organizer | Researcher",
      institute: "Patuakhali Science and Technology University",
      start: 2,
      comment:
        "This is a highly useful service for everyone who is seeking opportunities. I am currently searching for scholarships, and this platform has been very helpful for me. Thanks to it, I have found and applied for several rare opportunities. I have already been called for interviews, which has greatly boosted my confidence and encouraged me to keep applying.",
    },
  ];