"use client"

import { RiPencilLine } from "react-icons/ri";
import { useDispatch } from "react-redux";
import { openModal } from "@/redux/slices/modalSlice";

const UpdatePopUpButton = () => {
    const dispatch = useDispatch();

  return (
    <div className="absolute -top-8 right-5 lg:right-10 rounded-2xl text-6xl text-[#65558F] bg-white cursor-pointer" onClick={() => {console.log("clicked"); dispatch(openModal({modalName: "updateProfile"}))}}>
        <RiPencilLine />
        {/* {
            isUpdateFromOpen && <UpdateProfileForm />
        } */}
      </div>
  );
}

export default UpdatePopUpButton;
