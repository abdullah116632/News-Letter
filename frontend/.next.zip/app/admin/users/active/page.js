import ActiveSubscribersTable from './ActiveSubsCriberTable';

const page = () => {
  return (
    <div>
      <ActiveSubscribersTable />
    </div>
  );
}

export default page;
