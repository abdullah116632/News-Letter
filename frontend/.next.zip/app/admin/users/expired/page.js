import ExpiredSubscribersUser from './ExpiredSubscribersUser';

const page = () => {
  return (
    <div>
      <ExpiredSubscribersUser />
    </div>
  );
}

export default page;
