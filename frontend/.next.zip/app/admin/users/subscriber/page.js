import UserTable from "../UserTableBase";
import AllSubscibersTable from "./AllSubscribersTable";

const Subscriber = () => {
  return (
    <div>
      <AllSubscibersTable />
    </div>
  );
}

export default Subscriber;