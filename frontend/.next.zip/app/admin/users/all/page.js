import AllUserTable from "./AllUserTable";

const Users = () => {
  return (
    <div>
      <AllUserTable />
    </div>
  );
}

export default Users;
